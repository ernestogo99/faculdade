#include <stdio.h>
#include <stdlib.h>
#include "listaencad.h" 

int main() {
    Registro *lista;
     inicializarLista(&lista);

    // Carregar dados do arquivo "dados.txt" para a lista
    if (carregarDados(&lista, "dados.txt")) {
        printf("Dados carregados com sucesso!\n");
    } else {
        printf("Erro ao carregar os dados do arquivo.\n");
    }

    // Inserir novos registros na lista
    inserirRegistro(&lista, "Jonas", 1234, 11, 99998887, "jonas@email.com", 'P');
    inserirRegistro(&lista, "Mariana", 5678, 21, 98765432, "mariana@email.com", 'C');

    // Salvar a lista atualizada no arquivo "dados.txt"
    if (salvarDados(lista, "dados.txt")) {
        printf("Dados salvos com sucesso!\n");
    } else {
        printf("Erro ao salvar os dados no arquivo.\n");
    }

    // Percorrer e imprimir a lista
    printf("Registros na lista:\n");
    percorrerLista(lista);

    // Liberar a memória alocada para a lista
    free(lista);

    return 0;
}
