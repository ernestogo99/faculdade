void liberar_vetor(void *);
void *criar_vetor(int);
double obter_vetor(void *,int);
int atribuir_vetor(void *,int ,double);
//funções da matriz
void *criarmatriz(int,int);
double obtermatriz(void *,int,int);
int atribuir_matriz(void *,int,int,double);
void liberarmatriz(void *);

